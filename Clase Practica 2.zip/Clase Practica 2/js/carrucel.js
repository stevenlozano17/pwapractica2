document.addEventListener("DOMContentLoaded", () => {
    const carousel = document.querySelector("#miCarrusel");
    const bsCarousel = new bootstrap.Carousel(carousel, {
        interval: false,  
        wrap: true         
    });

    document.querySelector("#nextBtn").addEventListener("click", () => {
        bsCarousel.next();
    });

    document.querySelector("#prevBtn").addEventListener("click", () => {
        bsCarousel.prev();
    });
});
